# Current Chapter 5 project rules

The user authorized this independent Chapter 5 workspace and organization on 2026-11-13. Scope: robust communication reinforcement learning built on the selected Chapter 3 RL/map/planning baseline. Exclude TUM/German-thesis/BVPC work.

- `core` and `chapter3_bser` are inherited source. Record their parent identity using `provenance/ch3_parent_snapshot.json`; do not rewrite that parent manifest after changes.
- Chapter 5-specific runtime code belongs in `chapter5_comm`. The user's latest 2026-11-13 request authorizes actual task/map integration, factual labels, learners and evaluation. Run only bounded short tests; do not start long training.
- This directory is self-contained. Do not import sibling repositories, protected legacy CH5, or `CH5-Research/references` at runtime. Do not add sys.path injections or symlinks to them.
- The inherited source includes multiple RL/map research variants. Freeze the actual third-chapter baseline and configuration before comparing methods. Source copying is not training admission or performance acceptance.
- Preserve task, reward, target, obstacle, collision and mission-success semantics unless the user explicitly requests identified changes. Communication interface evolution must be explicit and independently identified from the Chapter 3 baseline.
- The user's all-channel choice on 2026-11-13 supersedes the earlier limited-channel suggestion: target, teammate state and map sharing are all constrained. Found/phase, planning commands, ACKs, retransmissions and relays must also use the declared channel and budget. No reliable shared map or free global Found/control side channel is allowed; public mission metadata remains explicit.
- Receiver policy, planning, navigation, action masks and fallback may only consume legal local information. The explicit CH5 adapter is `chapter5_comm/runtime.py`; directly invoking the inherited runtime does not establish compliance with the new protocol.
- The current neural architecture is `docs/CH5_NEURAL_MODULES_V3_20261113.md`; `docs/CH5_REDESIGN_20261113.md` remains the supporting protocol/system design. The two core network candidates are task-query packet compression and geometry-conditioned temporal decoding. The budgeted scheduler is a standard policy interface; CVaR is a standard optional training variant. Neither is automatically an independent novelty claim.
- Synthetic auxiliary-loss gradients do not establish end-to-end task RL. Label providers, third-chapter feature adapters, channels, learners and task performance must each be separately implemented and verified.
- Do not copy old 139D weights into the inherited 28D interfaces or relabel historical experiments as new CH5 results.
- Historical results, reference material, bundles and parent evidence are immutable. Uncertain claims or artifacts are REVIEW_REQUIRED.
- No long training or historical checkpoint restore. Commit/push require explicit user authorization; the user's 2026-11-15 request authorizes publishing the complete current source and inherited RL/map base to `https://github.com/SKT-T1otto/CH5-research.git`. The authorized short workflow may restore its own newly created CH5 checkpoint to verify inference on new episodes. Replay and active environment resume are not implemented.
- Report actual implementation, protocol checks, independent training seeds and performance evidence separately. Never turn a design formula, copied evidence or evaluation overlay into a completed experiment claim.
- Record created/modified/moved files, use task-appropriate checks and wait for all terminal commands before completion.

The user's 2026-11-16 request authorizes preparing and publishing complete Linux
experiment scripts and presets to the same GitHub repository. This authorizes
manual Linux pilot/formal entry points, new episode-boundary checkpoint/replay
serialization and explicit network ablations. It does not authorize running
long training on this computer. Keep the original bounded `ch5 smoke` guard;
extended runs use the separate `ch5-experiment` launcher and explicit execution.
Historical checkpoints/results remain immutable. New experiment checkpoints
may resume only their own frozen source/config/seed/arm at a committed boundary.
